package com.training.crudmakanan.model;

/**
 * Created by Blackswan on 5/24/2017.
 */

public class Respon {
    String msg;
    String result;

    public String getMsg() {
        return msg;
    }

    public void setMsg(String msg) {
        this.msg = msg;
    }

    public String getResult() {
        return result;
    }

    public void setResult(String result) {
        this.result = result;
    }

}
