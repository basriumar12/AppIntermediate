package com.training.crudmakanan.helper;

/**
 * Created by Blackswan on 8/29/2017.
 */

public class MyConstant {
    public static final int REQ_FILE_CHOOSE = 1;
    public static final int STORAGE_PERMISSION_CODE = 2;
    public static final String REGISTER = "http://192.168.20.35/db_makanan/register.php";
    public static final String BASE_URL = "http://192.168.20.35/db_makanan/";
    public static final String UPLOAD_MAKANAN = "http://192.168.20.35/db_makanan/uploadmakanan.php";
    public static final String UPLOAD_UPDATE_MAKANAN ="http://192.168.20.35/db_makanan/uploadupdatemakanan.php" ;
}
